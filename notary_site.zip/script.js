document.addEventListener('DOMContentLoaded', () => {
  const calendar = document.getElementById('calendar');
  if (calendar) {
    calendar.innerHTML = '<p>Booking calendar will go here.</p>';
  }
});